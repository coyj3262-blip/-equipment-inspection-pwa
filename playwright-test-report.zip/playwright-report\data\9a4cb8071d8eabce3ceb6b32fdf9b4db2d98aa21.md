# Page snapshot

```yaml
- generic [ref=e4]:
  - generic [ref=e5]:
    - generic [ref=e8]:
      - heading "Time Clock" [level=1] [ref=e9]
      - paragraph [ref=e10]: No active job sites available
    - paragraph [ref=e12]: Contact your supervisor to add job sites.
  - navigation [ref=e13]:
    - generic [ref=e14]:
      - link "Dashboard" [ref=e15] [cursor=pointer]:
        - /url: /dashboard
        - img [ref=e17]
        - generic [ref=e22]: Dashboard
      - link "Inspect" [ref=e23] [cursor=pointer]:
        - /url: /inspect
        - img [ref=e25]
        - generic [ref=e29]: Inspect
      - link "Library" [ref=e30] [cursor=pointer]:
        - /url: /library
        - img [ref=e32]
        - generic [ref=e35]: Library
      - link "More" [ref=e36] [cursor=pointer]:
        - /url: /more
        - img [ref=e38]
        - generic [ref=e39]: More
```